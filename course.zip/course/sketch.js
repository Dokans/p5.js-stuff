let point;
let walls = new Array(100);
//let blobs = [];


function setup() {
  createCanvas(600, 600);
  
  
  walls[0] = new Wall(null);
  for(let j = 1; j < walls.length; j++){
    walls[j] = new Wall(walls[j-1]);
  }
  /*
  for(let j = 0; j < walls.length; j++){
    blobs[j] = new Blob();
  }
  */
  point = new Point(walls[0].beginPoint.x, walls[0].beginPoint.y);
}



function draw() {
  background(0);
  checkKeys();
  point.update();


  for (let wall of walls) {
    wall.show();
  }

 /* for(let blob of blobs){
    blob.show();
  }*/

  point.show();
}



class Blob {

  constructor() {

    this.pos = createVector(random(-width, width * 2), random(-height, height * 2));
    this.color = [random(0, 255), random(0, 255), random(0, 255)];

  }

  show() {
    push();
    translate(this.pos.x - point.pos.x, this.pos.y - point.pos.y);
    fill(this.color[0], this.color[1], this.color[2]);
    ellipse(0, 0, 10);
    pop();
  }
}


function checkKeys() {
  if (keyIsDown(65)) {
    point.applyForce(createVector(-1, 0))
  }
  if (keyIsDown(68)) {
    point.applyForce(createVector(1, 0))
  }
  if (keyIsDown(87)) {
    point.applyForce(createVector(0, -1))
  }
  if (keyIsDown(83)) {
    point.applyForce(createVector(0, 1))
  }

}