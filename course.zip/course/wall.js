

class Wall {

    constructor(ancestor) {

        if (ancestor !== null) {
            this.ancestor = ancestor;
            this.beginPoint = ancestor.finalPoint
            this.angle = ancestor.angle + this.getAngle();
            if (this.angle > TWO_PI) {
                this.angle -= TWO_PI;
            }

            this.sideLines = new Array(2);
            this.lenght = random(100, 200);
        } else {

            this.beginPoint = createVector(width / 2, height / 2);
            this.angle = -PI / 2;
            this.lenght = 150;
        }

        this.finalPoint = this.getEndPoint();


    }

    getAngle() {

        let angle = randomGaussian(0, PI / 4)
        if (abs(angle) < PI / 4) {
            return 0;
        } else {
            return map(angle, -2 * PI / 3, 2 * PI / 3, -PI / 2, PI / 2);
        }
    }

    getEndPoint() {

        let fx = cos(this.angle) * this.lenght;
        let fy = sin(this.angle) * this.lenght
        let end = createVector(fx, fy);
        return end.add(this.beginPoint);
    }

    show() {
        push();
        translate(this.beginPoint.x - point.pos.x + 300, this.beginPoint.y - point.pos.y + 300);
        stroke(255);
        line(0, 0, this.finalPoint.x - this.beginPoint.x, this.finalPoint.y - this.beginPoint.y);
        pop()

    }

}